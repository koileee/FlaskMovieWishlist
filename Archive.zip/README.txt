# my Wishlist
An application where you can create a wishlist for various things.

The Python Flask web application will connect to the MySQL db on GCP through configurations
