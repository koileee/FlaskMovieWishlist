from flask import Flask, render_template, request, Response, redirect, url_for
import sqlalchemy
import os
import pymysql

# from dotenv import load_dotenv
#
# basedir = os.path.abspath(os.path.dirname(__file__))
# load_dotenv(os.path.join(basedir, '.env'))
#
# db_user = os.getenv("MYSQL_USER")
# db_pass = os.getenv("MYSQL_PASS")
# db_name = os.getenv("MYSQL_DB")
# cloud_sql_connection_name = os.getenv("CLOUD_SQL_CONNECTION_NAME")


cloud_sql_connection_name = os.environ.get("CLOUD_SQL_CONNECTION_NAME")



prod = True


app = Flask(__name__)

#connect = "mysql+pymysql://{}:{}@/{}?unix_socket=/cloudsql/{}"""
#db = create_engine(connect.format(db_user,db_pass,db_name,cloud_sql_connection_name))


if prod:
    db_user = os.environ.get("MYSQL_USER")
    db_pass = os.environ.get("MYSQL_PASSWORD")
    db_name = os.environ.get("MYSQL_DB")
    db = sqlalchemy.create_engine(
        sqlalchemy.engine.url.URL(
            drivername='mysql+pymysql',
            username=db_user,
            password=db_pass,
            database=db_name,
            query={'unix_socket': '/cloudsql/{}'.format(cloud_sql_connection_name)}
        ),
    )
else:
    db_user='root'
    db_pass='password348'
    db_name='test'
    db = sqlalchemy.create_engine(
        sqlalchemy.engine.url.URL(
            drivername='mysql+pymysql',
            username=db_user,
            password=db_pass,
            database=db_name,
            # query={'unix_socket': '/cloudsql/{}'.format(cloud_sql_connection_name)}
        ),
    )


@app.route('/')
def hello_world():
    data = []
    with db.connect() as conn:
        data = conn.execute(
            "Select movie_title, imdb_score, genres from MOVIE_USER;"
        ).fetchall()

    return render_template('template.html', outdata=data)


@app.route('/filter',  methods=['GET', 'POST'])
def abc():
    if request.method == 'POST':
        select = request.form.get('genre')
        if select == "All":
            return redirect(url_for('hello_world'))
        with db.connect() as conn:
            data = conn.execute(
                """Select movie_title, imdb_score, genres from MOVIE_USER where
                genres like %s limit 10;""", [select+"%"]
            ).fetchall()
        return(render_template('template.html', outdata=data))

if __name__ == '__main__':
    app.run(host="127.0.0.1", port=8080, debug=True)
